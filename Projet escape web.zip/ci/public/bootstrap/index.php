<!DOCTYPE html>

<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>escapeweb</title>
    <link rel="stylesheet" href="css/components.css">
    <link rel="stylesheet" href="css/icons.css">
    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">     
    <link rel="stylesheet" href="css/template-style.css">
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>      
  </head>

  <body class="size-1140">
    <!-- HEADER -->
    <header role="banner" class="position-absolute">    
      <!-- Top Navigation -->
      <nav class="background-transparent background-transparent-hightlight full-width sticky">
        <div class="s-12 l-2">
          <a href="index.html" class="logo">
            <!-- Logo White Version -->
            <img class="logo-white" src="img/morbihandark.png" alt="">
            <!-- Logo Dark Version -->
            <img class="logo-dark" src="img/morbihan3.png" alt="">
          </a>
        </div>
        <div class="top-nav s-12 l-10">
          <p class="nav-text"></p>
          <ul class="right chevron">
            <li><a href="index.html">Home</a></li>
            <li><a href="products.html">Products</a></li>
            <li><a>Services</a>
              <ul>
                <li><a>Service 1</a>
                  <ul>
                    <li><a>Service 1 A</a></li>
                    <li><a>Service 1 B</a></li>
                  </ul>
                </li>
                <li><a>Service 2</a></li>
              </ul>
            </li>
            <li><a href="about.html">About</a></li>
            <li><a href="gallery.html">Gallery</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
      </nav>
    </header>
    
    <!-- MAIN -->
    <main role="main">    
      <!-- Main Header -->
      <header>
        <div class="carousel-default owl-carousel carousel-main carousel-nav-white background-dark text-center">
          <div class="item">
            <div class="s-12">
              <img src="img/accueil.jpg" alt="">
              <div class="carousel-content">
                <div class="content-center-vertical line">
                  <div class="margin-top-bottom-80">
                    <!-- Title -->
                    <h1 class="text-white margin-bottom-30 text-size-60 text-m-size-30 text-line-height-1">Découvrer le Morbihan<br> </h1>
                    <div class="s-12 m-10 l-8 center"><p class="text-white text-size-14 margin-bottom-40">Tester vos connaissances sur les villes du morbihan </p></div>
                    <div class="line">
                      <div class="s-12 m-12 l-3 center">
                        
                      </div>       
                    </div>  
                  </div>
                </div>
              </div>
            </div>
          </div>              
        </div>               
      </header>
    
      <!-- Section 1 -->
      <section class="section-small-padding background-white text-center"> 
        <div class="line">
          <div class="margin">
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <div class="padding-2x block-bordered">
               <!-- <i class="icon-sli-shield icon3x text-dark center margin-bottom-30"></i>-->
                <h2 class="text-thin">Scénario 1</h2>
                <p class="margin-bottom-30">Description</p>
                <a class="button button-dark-stroke text-size-12" href="/">GET MORE INFO</a>
              </div>
            </div>
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <div class="padding-2x block-bordered">
               <!-- <i class="icon-sli-umbrella icon3x text-dark center margin-bottom-30"></i>-->
                <h2 class="text-thin">Scénario 2</h2>
                <p class="margin-bottom-30"> Description</p>
                <a class="button button-dark-stroke text-size-12" href="/">GET MORE INFO</a>
              </div>
            </div>
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <div class="padding-2x block-bordered">
               <!--<i class="icon-sli-home icon3x text-dark center margin-bottom-30"></i>-->
                <h2 class="text-thin">Scénario 3</h2>
                <p class="margin-bottom-30">Description</p>
                <a class="button button-dark-stroke text-size-12" href="/">GET MORE INFO</a>
              </div>
            </div>
          </div>
        </div>
      </section> 
      
      <!-- Section 5 -->    
      <section class="section background-white text-center">
        <div class="line">
          <h2 class="text-size-50 text-center">Actualités</h2>
          <hr class="break-small background-primary break-center">
          <div class="carousel-default owl-carousel carousel-wide-arrows">
            <div class="item">
              <div class="s-12 m-12 l-7 center text-center">
                <img class="image-testimonial-small" src="" alt="">
                <p class="h1 margin-bottom text-size-20">Actualité 1</p>
                <p class="h1 text-size-16"></p>
              </div>
            </div>
            <div class="item"> 
              <div class="s-12 m-12 l-7 center text-center">
                <img class="image-testimonial-small" src="" alt="">
                <p class="h1 margin-bottom text-size-20">Actualité 2</p>
                <p class="h1 text-size-16"></h5>
              </div>
            </div>
            <div class="item">
              <div class="s-12 m-12 l-7 center text-center">
                <img class="image-testimonial-small" src="" alt="">
                <p class="h1 margin-bottom text-size-20">Acualité 3</p>
                <p class="h1 text-size-16"></p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    	<?php
			$mysqli = new mysqli('localhost','e22104248sql','pjPhvfxF','e22104248_db2');
			if ($mysqli->connect_errno) {
				echo"Error: Problème de connexion à la BDD \n ";
				echo "Error:".$mysqli->connect_errno."\n";
				echo "Error:".$mysqli->connect_error."\n";
			}
			?>
      		<?php

				//Préparation du mot de passe de l’utilisateur tuxie
				$userspassword = "SELECT cpt_MotDePasse FROM t_compte_cpt WHERE cpt_idCompte = 7;";
        $mdp=$mysqli->query($userspassword);
        // On rajoute du sel...
				// pour empêcher les attaques par "Rainbow Tables" cf
				// http://en.wikipedia.org/wiki/Rainbow_table
        $salt = "sel:rugbyChess583?";

        if (!$mdp)
				{
					echo"Error: La requète a échoué \n ";
					echo "Error:".$mysqli->errno."\n";
					echo "Error:".$mysqli->error."\n";
				}
				else
				{
					$req= $mdp-> fetch_assoc();
          // Le mot de passe rallongé sera donc :
				  // OnRajouteDuSelPourAllongerleMDP123!!45678__TestCeciEstMonMotdePasse!123
				  $password = hash('sha256', $req['cpt_MotDePasse'].$salt);
				  //echo $password;
				  // Constitution par concaténation d'une requête UPDATE + exécution
				  $requete = "UPDATE t_compte_cpt SET cpt_MotDePasse='".$password."' WHERE cpt_MotDePasse ='".$req['cpt_MotDePasse']."';";
				  //echo($requete);
				  $resultat=$mysqli->query($requete);
				  /*Modification du mot de passe du profil de login tuxie*/
				  if (!$resultat)
				  {
					  echo"Error: La requète a échoué \n ";
					  echo "Error:".$mysqli->errno."\n";
					  echo "Error:".$mysqli->error."\n";
				  }
				  else
				  {
            
					  echo ("requete reussi");
				  }
					
				}

				
				
				
					//Fermeture de la communication avec la base MariaDB
			
				?>
        <?php
          $recuperation = "SELECT sce_image FROM t_scenario_sce 
          ORDER BY sce_id_scenario DESC LIMIT 1";
          $image=$mysqli->query($recuperation);


          if (!$image)
				  {
					  echo"Error: La requète a échoué \n ";
					  echo "Error:".$mysqli->errno."\n";
					  echo "Error:".$mysqli->error."\n";
				  }
				  else
				  {
            $reqSce= $image-> fetch_assoc();
            $chemin="documents/".$reqSce['sce_image'];
            echo "<img src=".$chemin." />";
					 
				  }

        ?>
   

    <!-- FOOTER -->
    <footer>
      <!-- Main Footer -->
      <section class="background-dark full-width">
      <!-- Bottom Footer -->
      <section class="padding background-dark full-width">
        <div class="s-12 l-6">
          <p class="text-size-12">Copyright 2023</p>
          <p class="text-size-12">Morbihan</p>
        </div>
        <div class="s-12 l-6">
          <a class="right text-size-12" href="http://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and coding<br> by LE DORTZ Andréa</a>
        </div>
      </section>
    </footer>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
  </body>
</html>
		<?php
			$mysqli->close();
		?>