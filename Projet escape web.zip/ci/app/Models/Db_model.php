<?php
namespace App\Models;
use CodeIgniter\Model;

class Db_model extends Model
{
	protected $db;
	public function __construct()
	{
		$this->db = db_connect(); //charger la base de données
		// ou
		// $this->db = \Config\Database::connect();
	}
	//ACTUALITE
	//fonction qui recupere toutes les informations d'une actualite
	public function get_actualite($numero)
	{
		$requete="SELECT * FROM t_actualite_act WHERE act_idActualite=".$numero.";";
		$resultat = $this->db->query($requete);
		return $resultat->getRow();
	}

	//fonction qui recupere  les informations des actualités qui sont publiés
	public function get_all_actualite()
	{
		$resultat = $this->db->query("SELECT act_intitule, act_description,act_date, cpt_login
		FROM t_actualite_act JOIN t_compte_cpt USING (cpt_idCompte)WHERE act_etat='P';");
		return $resultat->getResultArray();
	}	
	//COMPTE ET CONNEXION
	//Fonction qui utilise la vue permettant de recupere le nom,le prenom,le pseudo,le role et l'etat ordonnee par etat
	public function get_all_compte()
	{
		$resultat = $this->db->query("SELECT * FROM vue_liste_profils;");
		return $resultat->getResultArray();
	}

	//Fonction qui compte le nombre de comptes dans la table
	public function membre(){
		
		$resultat = $this->db->query("SELECT COUNT(*) AS total  FROM t_compte_cpt;");
		return $resultat->getRow();
	}
	//Insetion d'un nouveau compte (utilise le trigger de salage)
	public function set_compte($saisie)
	{
		//Récupération (+ traitement si nécessaire) des données du formulaire
		$login = $saisie['pseudo'];
		$mot_de_passe = $saisie['mdp'];
		$nom = $saisie['nom'];
		$prenom = $saisie['prenom'];
		$role = $saisie['role'];  
	
		$sql = "INSERT INTO t_compte_cpt VALUES(NULL, '".$mot_de_passe."', '".$login."', '".$nom."', '".$prenom."', '".$role."', 'A');";
	
		return $this->db->query($sql);
	}
	//fonction qui permet la connexion a un compte activé de se connecter
	public function connect_compte($u,$p)
	{$Mdphache = hash('sha256', $p . 'sel:rugbyChess583?');

		$sql = "SELECT cpt_login, cpt_MotDePasse FROM t_compte_cpt WHERE cpt_login = '".$u."' AND cpt_MotDePasse = '".$Mdphache."'AND cpt_etat='A'";
		
		$resultat=$this->db->query($sql);
		if($resultat->getNumRows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	//recupere toutes les donnée d'un profil précis
	public function profil($p){
		$sql="SELECT * FROM t_compte_cpt WHERE cpt_login='".$p."'and cpt_etat='A';";
		$resultat = $this->db->query($sql);
		return $resultat->getRow();
		
	}
	// Dans le modèle (Db_model)
	public function pseudoExists($pseudo)
	{
    	$requete = "SELECT COUNT(*) AS count FROM t_compte_cpt WHERE cpt_login = '$pseudo';";
    	$resultat = $this->db->query($requete);
    	$row = $resultat->getRow();
    
    return ($row->count > 0); // Retourne true si le pseudo existe, sinon false
}

//Fonction UPDATE permettant la modification d'un mot de passe
	public function modification($profil,$saisie){
		$a = $saisie['ancien'];
		$n = $saisie['new'];
		$Mdphacheancien = hash('sha256', $a . 'sel:rugbyChess583?');
		$Mdphachenew = hash('sha256', $n . 'sel:rugbyChess583?');
		$sql= "UPDATE t_compte_cpt SET cpt_MotDePasse='".$Mdphachenew."'WHERE cpt_login ='".$profil."' and cpt_MotDePasse='".$Mdphacheancien."';";
		$resultat = $this->db->query($sql);
		if ($resultat) {
    		$numRowsAffected = $this->db->affected_rows;
    		return $numRowsAffected > 0;
		} else {
    		return false;
		}
	}
//SCENARIO
//recupere les données des scenario activés avec Jointure a la table etape
	public function get_scenario()
	{
		$requete="SELECT  sce_intitule,cpt_login,sce_image,sce_code,etp_idEtape FROM t_scenario_sce 
		JOIN t_compte_cpt USING (cpt_idCompte)
		LEFT JOIN t_etape_etp ON t_scenario_sce.sce_id_scenario=t_etape_etp.sce_id_scenario AND etp_ordre=1 
		WHERE sce_etat='A' ;";
		$resultat = $this->db->query($requete);
		return $resultat->getResultArray();
	}

	//Fonction qui affiche le detail des scenarii activés
		public function manage_scenario()
	{
		$requete="SELECT  sce_code,sce_id_scenario,sce_intitule,cpt_login,sce_image,COUNT(etp_idEtape) AS ETP FROM t_scenario_sce 
		JOIN t_compte_cpt USING (cpt_idCompte)
		LEFT JOIN t_etape_etp USING (sce_id_scenario) GROUP BY sce_intitule";
		$resultat = $this->db->query($requete);
		return $resultat->getResultArray();
	}




//Insetion d'un nouveau scenario avec un code aléatoire
	public function set_scenario($intitule,$description,$fichier,$etat,$profil){
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$code = '';
		//$fichier = htmlspecialchars($fichier);
		for ($i = 0; $i < 10; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }
		$sql = "INSERT INTO t_scenario_sce VALUES (NULL, '".$intitule."','".$description."', '".$code."', '".$etat."', '".$fichier."',".$profil.");";
		return $this->db->query($sql);

	}
	//recupere toutes les informations d'un scénario a l'aide de son code
	public function get_scenariocomplet($code){
		$requete="SELECT * FROM t_scenario_sce  LEFT JOIN t_etape_etp USING (`sce_id_scenario`) WHERE sce_code='".$code."';";
		
		$resultat = $this->db->query($requete);
		return $resultat->getResultArray();
	}

	//Apppelle a la procedure qui efface un scenario et tous ce qui lui est associé
	public function delete_scenario($id){
		$sql="CALL scenario_effacer(".$id."); ";
		return $this->db->query($sql);
	}
//recupere le code d'un scenario a l'aide du code d'une etape
	public function get_codescenario($code){
		$requete="SELECT sce_code ,sce_id_scenario FROM t_scenario_sce
		JOIN t_etape_etp USING (sce_id_scenario) 
		WHERE etp_code= '$code';";

		$resultat = $this->db->query($requete);
		return $resultat->getRow();
	}
	// Dans le modèle (Db_model)
	//Verifie que le scenario est dans la base
	public function scenarioExists($code)
	{
    	$requete = "SELECT COUNT(*) AS count FROM t_scenario_sce WHERE sce_code = '$code';";
    	$resultat = $this->db->query($requete);
    	$row = $resultat->getRow();
    
    	return ($row->count > 0); // Retourne true si le scénario existe, sinon false
	}

	//ETAPE
		//Fonction qui recupere les informations (avec indices) de la premiere étape d'un scenario
		public function get_etape($code,$num)
		{
			$requete="SELECT * FROM t_scenario_sce
			LEFT JOIN  t_etape_etp USING (sce_id_scenario) 
			JOIN t_ressource_res USING (res_idressource) 
			LEFT JOIN t_indice_ind ON t_etape_etp.etp_idEtape=t_indice_ind.etp_idEtape AND ind_niveau=$num
			WHERE sce_code= '$code' and etp_ordre=1;";
	
			$resultat = $this->db->query($requete);
			return $resultat->getRow();
		}
	//recupere toutes les informations d'une etape avec l'aide d'un niveau(pour indice)et d'un code
	public function get_etapesuivant($code,$niv){
		$requete="SELECT * FROM t_etape_etp
		JOIN t_ressource_res USING (res_idressource) 
		LEFT JOIN t_indice_ind ON t_etape_etp.etp_idEtape=t_indice_ind.etp_idEtape AND ind_niveau=$niv
		WHERE etp_code= '$code' ;";

		$resultat = $this->db->query($requete);
		return $resultat->getRow();	
	}
	//recupere le code et la reponse d'une etape (franchir etape)
	public function get_reponsesuivant($code){
		$requete="SELECT etp_code,etp_reponse FROM t_etape_etp 
		WHERE etp_code= '$code';";

		$resultat = $this->db->query($requete);
		return $resultat->getRow();
	}
//appelle de la fonction qui recupere le code suivant
	public function get_codesuivant($codeac) {
		
			$requete = "SELECT etapesuivante('" . $codeac . "') AS code_suivant;";
			$resultat = $this->db->query($requete);
		
			// Vérifier si une ligne a été renvoyée
			if ($resultat->getNumRows() > 0) {
				// Récupérer la valeur de la colonne code_suivant
				$row = $resultat->getRowArray(); 
				return $row['code_suivant'];//code de l'etape suivante
			} else {
				return null; //plus d'etape apres le code actuelle
			}
		
		
	}
		//recupere le code et la reponse de la premiere etape 
	public function get_reponse($code){
		$requete="SELECT etp_reponse,etp_code FROM t_etape_etp
		JOIN t_scenario_sce USING (sce_id_scenario) 
		WHERE sce_code= '$code' and etp_ordre=1;";

		$resultat = $this->db->query($requete);
		return $resultat->getRow();
	}

	//PARTICIPATION
	//insertion dans la table participant
	public function insert_participant($mail){
		$requete = "INSERT INTO t_participant_par VALUES (NULL, '" . $mail . "')";

		return $this->db->query($requete);
	} 
	//recupere l'id du participant qui a rentrer l'adresse mail a la fin du scenario
	public function get_participant($mail){
		$requete="SELECT par_idParticipant FROM t_participant_par
		WHERE par_mailParticipant= '$mail';";
		$resultat = $this->db->query($requete);
		return $resultat->getRow();	
	}

	//insertion dans la classe participation
	public function insert_participation($mail,$id,$niv){
		$requete = "INSERT INTO t_participation_ptc VALUES ('" . $mail . "', " . $id . ", CURDATE(), CURDATE(), " . $niv . ")";

		return $this->db->query($requete);
	} 


}

