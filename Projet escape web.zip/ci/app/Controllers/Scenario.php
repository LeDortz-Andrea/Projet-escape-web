<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Scenario extends BaseController
{
	public function __construct()
	{
		helper('form');
 		$this->model = model(Db_model::class);
	}
	public function afficher()
	{
		$model = model(Db_model::class);
		$data ['scenario']= $model -> get_scenario();
		$data['titre']="Liste de tous les Scénarii";
		return view('templates/haut', $data)
			.view('templates/menu_visiteur')
			. view('affichage_scenario')
			. view('templates/bas');
	}
	public function gestion(){
		$session=session();
 		if ($session->has('user'))
 		{
 			$data['le_message']="Affichage des données des scenarii !!!";
			$user=$session->get('user');
			 $data['profil'] = $this->model->profil($user);
			 $data['scenarii'] = $this->model->manage_scenario();

 				return view('templates/haut2',$data)
				 		. view('templates/menu_organisateur.php')
 					    . view('connexion/compte_scenario')
 						. view('templates/bas2');
 		}
 		else
		{
 			return view('templates/haut', ['titre' => 'Se connecter'])
 				    . view('connexion/compte_connecter')
 					. view('templates/bas');
 		}
	}
    public function visualiser($code=''){
    	$session=session();
 		if ($session->has('user'))
		 {
			$data['le_message']="Affichage des données du scenario !!!";
			$data['scenarii'] = $this->model->get_scenariocomplet($code);

				return view('templates/haut2',$data)
						. view('templates/menu_organisateur.php')
						. view('connexion/compte_visualision')
						. view('templates/bas2');
		}
		else
	   {
			return view('templates/haut', ['titre' => 'Se connecter'])
					. view('connexion/compte_connecter')
					. view('templates/bas');
		}
    }
	public function creer()
{
    $session = session();

    if ($session->has('user')) {
        if ($this->request->getMethod() == "post") {
            if (!$this->validate([
                'intitule' => 'required|max_length[255]|min_length[2]',
                'description' => 'required|max_length[255]|min_length[2]',
                'fichier' => [
                    'label' => 'Fichier image',
                    'rules' => [
                        'uploaded[fichier]',
                        'is_image[fichier]',
                        'mime_in[fichier,image/jpg,image/jpeg,image/gif,image/png,image/webp]',
                        'max_size[fichier,100]',
                        'max_dims[fichier,1024,768]',
                    ],
                ],
            ],
            [   // Configuration des messages d’erreurs
                'intitule' => [
                    'required' => 'Veuillez entrer un pseudo pour le compte !',
                    'max_length' => 'Le pseudo saisi est trop long !',
                    'min_length' => 'Le pseudo saisi est trop court !',
                ],
                'description' => [
                    'required' => 'Veuillez entrer un mot de passe !',
                    'min_length' => 'Le mot de passe saisi est trop court !',
                    'max_length' => 'Le mot de passe saisi est trop long !',
                ],
            ])) {
                return view('templates/haut2', ['titre' => 'Créer un Scenario'])
                    . view('templates/menu_organisateur')
                    . view('connexion/compte_creationscenario.php')
                    . view('templates/bas2');
            }

            $intitule = $this->request->getVar('intitule');
            $description = $this->request->getVar('description');
            $etat = $this->request->getVar('etat');
            $fichier = $this->request->getFile('fichier');
            $intitule = htmlspecialchars(addslashes($intitule));
            $description = htmlspecialchars(addslashes($description));

            if (!empty($fichier)) {
                // Récupération du nom du fichier téléversé
                $nom_fichier = $fichier->getName();
                $nom_fichier = htmlspecialchars(addslashes($nom_fichier));

                // Dépôt du fichier dans le répertoire ci/public/images
                if ($fichier->move("ressources", $nom_fichier)) {
                    // Le fichier a été téléversé avec succès, procéder avec le traitement

                    // Récupérer l'utilisateur actuellement connecté
                    $user = $session->get('user');

                    // Récupérer le profil de l'utilisateur à partir du modèle
                    $data['profil'] = $this->model->profil($user);

                    // Appeler la méthode set_scenario du modèle pour enregistrer les données du scénario
                    $this->model->set_scenario($intitule, $description, $nom_fichier, $etat, $data['profil']->cpt_idCompte);

                    // Retourner une vue avec les données mises à jour
					return  redirect('scenario/gestion');
					return view('templates/haut2', ['titre' => 'Créer un Scenario'])
					. view('templates/menu_organisateur')
					. view('connexion/compte_scenario')
					. view('templates/bas2');
                }
            }
        }
    }
    return view('templates/haut2', ['titre' => 'Créer un Scenario'])
        . view('templates/menu_organisateur')
        . view('connexion/compte_creationscenario')
        . view('templates/bas2');
}
public function supprimer($scenarioId) {
    $session = session();
    if ($session->has('user')) {
		$data ['scenario']= $this->model -> delete_scenario($scenarioId);
        return redirect()->to('/scenario/gestion');

    }
    else{
        redirect(base_url('index.php/compte/connecter'));
    }
}

}