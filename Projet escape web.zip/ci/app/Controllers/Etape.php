<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Etape extends BaseController
{
	public function __construct()
	{
		helper('form');
 		$this->model = model(Db_model::class);
	}

	public function afficher($code = "", $num = 0)
	{
		$model = model(Db_model::class);
			$data['lecode'] = $code;
			$data['niv'] = $num;
		
			// L’utilisateur veut afficher le formulaire pour créer un compte
			if (!empty($code) && $num > 0 && $num <= 3) {
				$data['etape'] = $this->model->get_etape($code, $num);
				if (!$this->model->scenarioExists($code)) {
					$data['erreur'] = "Scénario inexistant";
				} elseif ($data['etape'] == NULL) {
					$data['erreur'] = "Scénario sans étapes";
				}
				
		
				$data['titre'] = "Liste de tous les Scénarii";
				$data['intitule'] = "Premiere étape";
		
				// La validation du formulaire a réussi, traitement du formulaire
				if ($this->request->getMethod() == "post") {
					$rules = [
						'reponse' => 'required',
						'thecode' => 'required',
						'theniv' => 'required',
					];
		
					if (!$this->validate($rules)) {
						return redirect()->to('/etape/afficher/' . $code . '/' . $num);

					}
		
					$recuperation = $this->validator->getValidated();
					$recuperation['reponse'] = htmlspecialchars(addslashes($recuperation['reponse']));
					$recuperation['thecode'] = htmlspecialchars(addslashes($recuperation['thecode']));
					$data['etape'] = $this->model->get_reponse($recuperation['thecode']);
		
					// Vérifier si $data['etape'] est défini et a une propriété etp_reponse
					if (isset($data['etape']->etp_reponse) && $recuperation['reponse'] == $data['etape']->etp_reponse) {
						// Traitement si la réponse est correcte
						$codeSuivant = $model->get_codesuivant($data['etape']->etp_code);
		
						if ($codeSuivant !== null) {
							return redirect()->to('/etape/franchir/' . $codeSuivant . '/' . $recuperation['theniv']);
						} else {
							// Gérer le cas où aucune étape suivante n'est trouvée
							return redirect()->to('/scenario/afficher');
						}
					} else {
						// Redirection si la réponse est incorrecte
						return redirect()->to('/etape/afficher/' . $recuperation['thecode'] . '/' . $recuperation['theniv']);
					}
				}
		
				return view('templates/haut', $data)
					. view('templates/menu_visiteur')
					. view('affichage_etape')
					. view('templates/bas');
			}
		
			return redirect()->to('/scenario/afficher');
		}
		
   

		public function franchir($code = "", $num = 0)
		{
			$model = model(Db_model::class);
			$data['lecode'] = $code;
			$data['niv'] = $num;
		
			// L’utilisateur veut afficher le formulaire pour créer un compte
			if (!empty($code) && $num > 0 && $num <= 3) {
				$data['etapes'] = $model->get_etapesuivant($code, $num);
		
		
				// La validation du formulaire a réussi, traitement du formulaire
				if ($this->request->getMethod() == "post") {
					$rules = [
						'reponse' => 'required',
						'thecode' => 'required',
						'theniv' => 'required',
					];
		
					if (!$this->validate($rules)) {
						return redirect()->to('/etape/franchir/' . $code . '/' . $num);
					}
		
					$recuperation = $this->request->getPost();
					$data['etape'] = $model->get_reponsesuivant($recuperation['thecode']);
		
					// Vérifier si $data['etape'] est défini et a une propriété etp_reponse
					if (isset($data['etape']->etp_reponse) && $recuperation['reponse'] == $data['etape']->etp_reponse) {
						// Traitement si la réponse est correcte
						$codeSuivant = $model->get_codesuivant($data['etape']->etp_code);
		
						if ($codeSuivant !== null) {
							return redirect()->to('/etape/franchir/' . $codeSuivant . '/' . $recuperation['theniv']);
						} else {
							// Gérer le cas où aucune étape suivante n'est trouvée
							$data['codesce']=$model->get_codescenario($code);
							$data['code1']= $model->get_reponse($data['codesce']->sce_code);
							return redirect()->to('/etape/completer/' . $data['code1']->etp_code. $data['etape']->etp_code . '/' . $recuperation['theniv']);
						}
					} else {
						// Redirection si la réponse est incorrecte
						return redirect()->to('/etape/franchir/' . $recuperation['thecode'] . '/' . $recuperation['theniv']);
					}
				}
		
				return view('templates/haut', $data)
					. view('templates/menu_visiteur')
					. view('franchir_etape')
					. view('templates/bas');
			}
		
			return redirect()->to('/scenario/afficher');
		}
		

public function completer($code="",$num=0){
	$model = model(Db_model::class);
			$data['lecode'] = $code;
			$data['niv'] = $num;
		
			// L’utilisateur veut afficher le formulaire pour créer un compte
			if (!empty($code) && $num > 0 && $num <= 3) {
				// La validation du formulaire a réussi, traitement du formulaire
				if ($this->request->getMethod() == "post") {
					$rules = [
						'reponse' => 'required',
						'thecode' => 'required',
						'theniv' => 'required',
					];
		
					if (!$this->validate($rules)) {
						return redirect()->to('/etape/completer/' . $code . '/' . $num);
					}
		
					$recuperation = $this->request->getPost();
					$recuperation['reponse'] = htmlspecialchars(addslashes($recuperation['reponse']));

						// Traitement si la réponse est correcte
						$code1 = substr($code, 0, 8);
						$data['codesce']=$model->get_codescenario($code1);
						$data['mail'] = $this->model->get_participant($recuperation['reponse']);

						if($data['mail']==NULL){
			 				$this->model->insert_participant($recuperation['reponse']);
							 $data['mail'] = $this->model->get_participant($recuperation['reponse']);
							$this->model->insert_participation($data['mail']->par_idParticipant,$data['codesce']->sce_id_scenario,$recuperation['theniv']);

						}
						else{
							$this->model->insert_participation($data['mail']->par_idParticipant,$data['codesce']->sce_id_scenario,$recuperation['theniv']);
						}
						return redirect()->to('/scenario/afficher');

		
					} 
				
				return view('templates/haut', $data)
					. view('templates/menu_visiteur')
					. view('affichage_reussitesce')
					. view('templates/bas');
				}	
				return redirect()->to('/scenario/afficher');
			}
		}		
