<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Compte extends BaseController
{
	public function __construct()
	{
		helper('form');
 		$this->model = model(Db_model::class);
	}
	public function lister()
	{
		$session=session();
 		if ($session->has('user'))
 		{
			$user=$session->get('user');
			$data['profil'] =$this->model->profil($user);
			
			if ($data['profil']->cpt_role == 'A') {
				$data ['totalmembre']= $this->model -> membre();
				$data['titre']="Liste de tous les comptes";
				$data['logins'] = $this->model->get_all_compte();
				return view('templates/haut2', $data)
					.view('templates/menu_administrateur')
					. view('affichage_compte')
					. view('templates/bas2');

			}
			else
			{
				 return view('templates/haut', ['titre' => 'Se connecter'])
						.view('templates/menu_visiteur.php')
						 . view('connexion/compte_connecter')
						 . view('templates/bas');
			 }
		}	
		else
		{
 			return view('templates/haut', ['titre' => 'Se connecter'])
					.view('templates/menu_visiteur.php')
 				    . view('connexion/compte_connecter')
 					. view('templates/bas');
 		}
	}	
	public function creer()
 	{
		$session=session();
		if ($session->has('user'))
		{
			$user=$session->get('user');
			$data['profil'] =$this->model->profil($user);
			
			if ($data['profil']->cpt_role == 'A') {
			// $this->model->set_compte($recuperation);
 			// L’utilisateur a validé le formulaire en cliquant sur le bouton
 			if ($this->request->getMethod()=="post")
 			{
 				 if (! $this->validate([
 					 	'pseudo' => 'required|max_length[255]|min_length[2]',
 						'nom' => 'required|max_length[255]|min_length[2]',
 			 			'prenom' => 'required|max_length[255]|min_length[2]',
			 			'mdp' => 'required|max_length[255]|min_length[8]',
			 			'mdp2' => 'required|max_length[255]|min_length[8]|matches[mdp]',	
 					],
 					[ // Configuration des messages d’erreurs
						'pseudo' => [
						'required' => 'Veuillez entrer un pseudo pour le compte !',
						'max_length' => 'Le pseudo saisi est trop long !',
						'min_length' => 'Le pseudo saisi est trop court !',
						],
						'mdp' => [
						'required' => 'Veuillez entrer un mot de passe !',
						'min_length' => 'Le mot de passe saisi est trop court !',
						'max_length' => 'Le mot de passe saisi est trop long !',
						],
						'nom' => [
						'required' => 'Veuillez entrer un nom pour le compte !',
						'min_lenth' => 'Le nom saisi est trop court !',
						'max_length' => 'Le nom saisi est trop long !',
						],
						'prenom' => [
						'required' => 'Veuillez entrer un prenom pour le compte !',
						'min_lenth' => 'Le prenom saisi est trop court !',
						'max_length' => 'Le prenom saisi est trop long !',
						],
						'mdp2' => [
						'matches' => 'Les mots de passe ne correspondent pas !',
						'required' => 'Veuillez entrer un mot de passe !',
						'min_length' => 'Le mot de passe saisi est trop court !',
						'max_length' => 'Le mot de passe saisi est trop long !',
						],
					]
 					))

		 			{
				  // La validation du formulaire a échoué, retour au formulaire !
 						 return view('templates/haut2', ['titre' => 'Créer un compte'])
						  	 .view('templates/menu_administrateur')
 							 . view('compte/compte_creer')
	 						 . view('templates/bas2');
					 }
 					 // La validation du formulaire a réussi, traitement du formulaire
		 			 $recuperation = $this->validator->getValidated();
					 $recuperation['pseudo']= htmlspecialchars(addslashes($recuperation['pseudo']));
					 $recuperation['prenom']= htmlspecialchars(addslashes($recuperation['prenom']));
					 $recuperation['nom']= htmlspecialchars(addslashes($recuperation['nom']));
					 $recuperation['mdp']= htmlspecialchars(addslashes($recuperation['mdp']));
					 $recuperation['mdp2']= htmlspecialchars(addslashes($recuperation['mdp2']));
					 $recuperation['role'] = $_POST['role'];			
					 if ($this->model->pseudoExists($recuperation['pseudo'])) {
							return view('templates/haut2', ['titre' => 'Créer un compte'])
								.view('templates/menu_administrateur')
							   . view('compte/compte_creer')
							   . view('templates/bas2');
					} else {
						$this->model->set_compte($recuperation);
			 			 $data['le_compte']=$recuperation['pseudo'];
 						 $data['le_message']="Nouveau nombre de comptes : ";
 						 //Appel de la fonction créée dans le précédent tutoriel :
						  return redirect()->to('/compte/lister');
					}
				}			 
 				// L’utilisateur veut afficher le formulaire pour créer un compte
 	 			return view('templates/haut2', ['titre' => 'Créer un compte'])
		  			.view('templates/menu_administrateur')
 					. view('compte/compte_creer')
 					. view('templates/bas2');
 			}
			else{
				return view('templates/haut', ['titre' => 'Se connecter'])
					.view('templates/menu_visiteur.php')
					. view('connexion/compte_connecter')
					. view('templates/bas');
			}
		}
		else{
			return view('templates/haut', ['titre' => 'Se connecter'])
					.view('templates/menu_visiteur.php')
					. view('connexion/compte_connecter')
					. view('templates/bas');
		}
	}

 	public function connecter()
	{
		$session=session();
 		if ($session->has('user'))
 		{
			$user=$session->get('user');
			$data['profil'] =$this->model->profil($user);
			
			if ($data['profil']->cpt_role == 'A') {
				return view('templates/haut2')
					. view('templates/menu_administrateur.php')
					. view('connexion/compte_accueil')
					. view('templates/bas2');

			} else if ($data['profil']->cpt_role == 'O') {
				return view('templates/haut2')
					. view('templates/menu_organisateur.php')
					. view('connexion/compte_accueil')
					. view('templates/bas2');
			}
			else{
				return view('templates/haut', ['titre' => 'Se connecter'])
					. view('connexion/compte_connecter')
					.view('templates/menu_visiteur.php')
					. view('templates/bas');
			}
		}
		else{
		//L’utilisateur a validé le formulaire en cliquant sur le bouton
			if ($this->request->getMethod()=="post"){
				if (! $this->validate([
					'pseudo' => 'required',
					'mdp' => 'required'
					]))
				{ // La validation du formulaire a échoué, retour au formulaire !
					return view('templates/haut', ['titre' => 'Se connecter'])
						.view('templates/menu_visiteur.php')
						. view('connexion/compte_connecter')
						. view('templates/bas');
				}
				// La validation du formulaire a réussi, traitement du formulaire
				$username=$this->request->getVar('pseudo');
				$password=$this->request->getVar('mdp');
				if ($this->model->connect_compte($username, $password) == true) {
					$session = session();
					$session->set('user', $username);
				
					$data['profil'] =$this->model->profil($username);

			
				if ($data['profil']->cpt_role == 'A') {
					return view('templates/haut2')
						. view('templates/menu_administrateur.php')
						. view('connexion/compte_accueil')
						. view('templates/bas2');

				} else if ($data['profil']->cpt_role == 'O') {
					return view('templates/haut2')
						. view('templates/menu_organisateur.php')
						. view('connexion/compte_accueil')
						. view('templates/bas2');
				}
				else{
					return view('templates/haut', ['titre' => 'Se connecter'])
						.view('templates/menu_visiteur.php')
						. view('connexion/compte_connecter')
						. view('templates/bas');
				}
			}
			else{
			 	return view('templates/haut', ['titre' => 'Echec d \'authentification, veuillez réessayez'])
						. view('connexion/compte_connecter')
						. view('templates/bas');
			}
			}
		// L’utilisateur veut afficher le formulaire pour se conncecter
			return view('templates/haut', ['titre' => 'Se connecter'])
				.view('templates/menu_visiteur.php')
				. view('connexion/compte_connecter')
				. view('templates/bas');
		}
	}

	 public function afficher_profil()
 	{
 		$session=session();
 		if ($session->has('user'))
 		{
 			$data['le_message']="Affichage des données du profil ici !!!";
			$user=$session->get('user');
			 $data['profil'] = $this->model->profil($user);
 			// A COMPLETER...
			 if ($data['profil']->cpt_role == 'O') {
 				return view('templates/haut2',$data)
				 		. view('templates/menu_organisateur.php')
 					    . view('connexion/compte_profil')
 						. view('templates/bas2');
			 }	
			 if ($data['profil']->cpt_role == 'A') {
				return view('templates/haut2',$data)
						. view('templates/menu_administrateur.php')
						. view('connexion/compte_profil')
						. view('templates/bas2');
			}	
		}
 		
 		else
		{
 			return view('templates/haut', ['titre' => 'Se connecter'])
					.view('templates/menu_visiteur.php')
 				    . view('connexion/compte_connecter')
 					. view('templates/bas');
 		}
 	}
	public function deconnecter()
 	{
 		$session=session();
 		$session->destroy();
 		return redirect()->to('/');
 	}
	public function modifier()
	{
		$session = session();
		if ($session->has('user')){
			$user=$session->get('user');
			$data['profil'] =$this->model->profil($user);
				
			if ($this->request->getMethod()=="post")
 			{
 			 	if (! $this->validate([
					'ancien' => 'required|max_length[255]|min_length[8]',
			 		'new' => 'required|max_length[255]|min_length[8]',
			 		'new2' => 'required|max_length[255]|min_length[8]|matches[new]',	
 				],
 				[ // Configuration des messages d’erreurs
					'ancien' => [
					'required' => 'Veuillez entrer un mot de passe !',
					'min_length' => 'Le mot de passe saisi est trop court !',
					'max_length' => 'Le mot de passe saisi est trop long !',
					],
					'new' => [
						'required' => 'Veuillez entrer un mot de passe !',
						'min_length' => 'Le mot de passe saisi est trop court !',
						'max_length' => 'Le mot de passe saisi est trop long !',
					],
					'new2' => [
						'matches' => 'Les mots de passe ne correspondent pas !',
						'required' => 'Veuillez entrer un mot de passe !',
						'min_length' => 'Le mot de passe saisi est trop court !',
						'max_length' => 'Le mot de passe saisi est trop long !',	
					],
				]
 				))
 				{
				  	// La validation du formulaire a échoué, retour au formulaire !
					if ($data['profil']->cpt_role == 'A') {
						return view('templates/haut2')
							. view('templates/menu_administrateur.php')
							. view('connexion/compte_modificationmdp.php')
							. view('templates/bas2');

					} else if ($data['profil']->cpt_role == 'O') {
						return view('templates/haut2')
							. view('templates/menu_organisateur.php')
							. view('connexion/compte_modificationmdp.php')
							. view('templates/bas2');
					}
				 }
 				 // La validation du formulaire a réussi, traitement du formulaire
				 $recuperation = $this->validator->getValidated();
			 	 $recuperation['ancien']= htmlspecialchars(addslashes($recuperation['ancien']));
				 $recuperation['new']= htmlspecialchars(addslashes($recuperation['new']));
			 	 $recuperation['new2'] = htmlspecialchars(addslashes($recuperation['new2']));;
				 $rec=$this->model ->modification(($data['profil']->cpt_login),$recuperation);
 				 $data['le_message']="Nouveau nombre de comptes : ";
					if ($data['profil']->cpt_role == 'A') {
					return redirect()->to('/compte/afficher_profil');
			   } else if ($data['profil']->cpt_role == 'O') {
					return redirect()->to('/compte/afficher_profil');
			   }
 			}
			// L’utilisateur veut afficher le formulaire pour créer un compte
			if ($data['profil']->cpt_role == 'A') {
				 return view('templates/haut2')
					. view('templates/menu_administrateur.php')
					. view('connexion/compte_modificationmdp.php')
					. view('templates/bas2');
			} else if ($data['profil']->cpt_role == 'O') {
				 return view('templates/haut2')
					. view('templates/menu_organisateur.php')
					. view('connexion/compte_modificationmdp.php')
					. view('templates/bas2');
			}
		}
 	}
}
