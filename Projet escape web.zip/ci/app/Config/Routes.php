<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
use App\Controllers\Accueil;
$routes->get('/',[Accueil::class,'afficher']);
$routes->get('accueil/afficher', [Accueil::class, 'afficher']);
//$routes->get('accueil/afficher/(:segment)', [Accueil::class, 'afficher']);

use App\Controllers\Compte;
$routes->get('compte/lister', [Compte::class, 'lister']);
//$routes->get('compte/creer', [Compte::class, 'creer']);
//$routes->post('compte/creer', [Compte::class, 'creer']); 
$routes->match(["get","post"],'compte/creer', [Compte::class, 'creer']);
$routes->get('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/connecter', [Compte::class, 'connecter']);
$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']);
$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);
//$routes->get('compte/afficher_profilA', [Compte::class, 'afficher_profilA']);  
$routes->match(["get","post"],'compte/modifier', [Compte::class, 'modifier']);

use App\Controllers\Actualite;
$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficher/(:num)', [Actualite::class, 'afficher']);

use App\Controllers\Scenario;
$routes->get('scenario/afficher', [Scenario::class, 'afficher']);
$routes->get('scenario/gestion', [Scenario::class, 'gestion']);
$routes->match(["get","post"],'scenario/creer', [Scenario::class, 'creer']);
$routes->get('scenario/visualiser/', [Scenario::class, 'visualiser']);
$routes->get('scenario/visualiser/(:alphanum)', [Scenario::class, 'visualiser']);
$routes->get('scenario/supprimer/(:num)', [Scenario::class, 'supprimer']);

use App\Controllers\Etape;
$routes->match(["get","post"],'etape/afficher', [Etape::class, 'afficher']);
$routes->match(["get","post"],'etape/afficher/(:alphanum)', [Etape::class, 'afficher']);
$routes->match(["get","post"],'etape/afficher/(:alphanum)/(:num)', [Etape::class, 'afficher']);

$routes->match(["get","post"],'etape/franchir', [Etape::class, 'franchir']);
$routes->match(["get","post"],'etape/franchir/(:alphanum)', [Etape::class, 'franchir']);
$routes->match(["get","post"],'etape/franchir/(:alphanum)/(:num)', [Etape::class, 'franchir']);

$routes->match(["get","post"],'etape/completer', [Etape::class, 'completer']);
$routes->match(["get","post"],'etape/completer/(:alphanum)', [Etape::class, 'completer']);
$routes->match(["get","post"],'etape/completer/(:alphanum)/(:num)', [Etape::class, 'completer']);