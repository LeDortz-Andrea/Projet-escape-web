
<?php


if (! empty($actualite)&& is_array($actualite))
{
    echo "<h2> Les dernieres actualités<h2>";
    echo"<table>
        <thead>
            <tr>
             <th>Titre</th>
             <th>Description</th>
             <th>Auteur</th>
             <th>Date de publication</th>
            </tr> 
        </thead><tbody>";
	foreach ($actualite as $news)
	{
        
	echo " <tr>
    <td>";
    echo $news['act_intitule']; 
    echo"</td><td>";
    echo $news['act_description']; 
    echo"</td><td>";
    echo $news['cpt_login']; 
    echo"</td><td>";
    echo $news['act_date']; 
    echo"</td></tr>";
    }
    echo"</tbody></table>";

	
}
 else {
    echo ("Pas d'actualité POUR LE MOMENT !");
}


?>


