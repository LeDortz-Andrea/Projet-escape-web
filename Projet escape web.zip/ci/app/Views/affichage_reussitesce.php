<h2> Félicitation vous venez de reussir le scenario </h2>
<h4>Veuillez saisir votre adresse mail afin d'enregistrer vos résultat</h4>

<?php echo form_open('/etape/completer/' . $lecode . '/' . $niv); ?>

    <?= csrf_field() ?>
    <label for="reponse">Votre email : </label>
    <input type="email" name="reponse">
    <input type="hidden" name="thecode" value="<?php echo $lecode; ?>">
    <input type="hidden" name="theniv" value="<?php echo $niv; ?>">
    <input type="submit" name="submit" value="Valider">
</form>