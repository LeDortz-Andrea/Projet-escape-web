<section>

<h2><?php echo $titre; ?></h2>
<?php
$session=session();
if (isset($totalmembre)){
	echo"Il y a ";
	echo $totalmembre->total;
	echo" membres.";
}
?>
<div class="table-data-feature">
<br>Ajouter un compte &nbsp;
	<button class="item" data-toggle="tooltip" data-placement="top" >
		<a href="<?php echo base_url();?>index.php/compte/creer">
			<i class="fas fa-plus"></i></a>
	</button> 
</div> 	
<br>
<?php
if (! empty($logins) && is_array($logins))
{
	echo"<br><div class='table-responsive table-responsive-data2'>
    <table class='table table-data2'>
    <thead>
		<tr>
		 <th>Nom</th>
		 <th>Prénom</th>
		 <th>Pseudo</th>
		
		 <th>Role</th>
		 <th>Etat</th>
		</tr> 
	</thead><tbody>";
	foreach ($logins as $pseudos)
	{
	echo " <tr class='tr-shadow'>
    <td>";
    echo $pseudos['cpt_nom']; 
    echo"</td><td>";
    echo $pseudos['cpt_prenom']; 
    echo"</td><td>";
    echo $pseudos["cpt_login"];
    echo"</td><td>";
    if ($pseudos['cpt_role']=='A'){
    	echo "Administrateur";
    }
    elseif($pseudos['cpt_role']=='O'){
    	echo "Organisateur";
    }
    else{
    	echo "erreur";
    }
	echo"</td><td>";
  
    if ($pseudos['cpt_etat']=='A'){
    	echo "Activer";
    }
    elseif($pseudos['cpt_etat']=='D'){
    	echo "Désactiver";
    }
    else{
    	echo "erreur";
    }

    echo"</td></tr>";
    }
    echo"</tbody></table></div>";
	}
else {
	echo("<h3>Aucun compte pour le moment</h3>");
}
?>
</section>

	