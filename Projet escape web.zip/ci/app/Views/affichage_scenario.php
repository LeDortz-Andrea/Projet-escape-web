<h1><?php echo $titre;?></h1><br />
<?php
echo "<section class='section-small-padding background-white text-center'>
          <div class='line'>
            <div class='margin'>";

if (!empty($scenario)) {
  
     foreach ($scenario as $pseudos) {
     
            echo "<div class='s-12 m-12 l-4 margin-m-bottom'>
                    <div class='padding-2x block-bordered'>";
            echo "<h2 class='text-thin'>" . $pseudos['sce_intitule'] . "</h2>";
            echo"Auteur: ". $pseudos['cpt_login'] ;
			echo "<i><img src='" . base_url('ressources/' . $pseudos['sce_image']) . "' alt=''></i>";
			
			echo "<p>Niveau de difficulté: ";
			echo "<a href='" . base_url('index.php/etape/afficher/' . $pseudos['sce_code']) . "/1'>";
			echo"facile </p></a>";
			
			echo "<p>Niveau de difficulté: ";
			echo "<a href='" . base_url('index.php/etape/afficher/' . $pseudos['sce_code']) . "/2'>";
			echo"Moyen </p></a>";
			
			echo "<p>Niveau de difficulté: ";
			echo "<a href='" . base_url('index.php/etape/afficher/' . $pseudos['sce_code']) . "/3'>";
			echo"Difficile </p></a>";
			echo"</div></div>";
	
			
		}
	}	



 else {
    echo("<h3>Aucun scénario pour le moment</h3>");
}

echo "</div></div></section>";
?>

        
              
              