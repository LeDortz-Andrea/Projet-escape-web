<h2><?php
$session=session();
  ?>Modifier votre Mot de Passe:</h2>
  <br><br>

<?= session()->getFlashdata('error') ?>

<?php echo form_open('/compte/modifier'); ?>
    <?= csrf_field() ?>
    <p>
        <label for="ancien">Ancien Mot de Passe:</label>
        <input type="password" id="ancien" name="ancien">
        <?= validation_show_error('ancien') ?>
    </p><br> 
    <p>
        <label for="new">Nouveau Mot de Passe:</label>
        <input type="password" id="new" name="new" required>
        <?= validation_show_error('new') ?>
    </p><br> 
    <p>
        <label for="new2">Confirmer le Nouveau Mot de Passe:</label>
        <input type="password" id="new2" name="new2">
        <?= validation_show_error('new2') ?>
    </p><br>
    
    <!-- Bouton pour annuler la modification -->
    <button type="button">
        <a href='<?php echo base_url('index.php/compte/afficher_profil'); ?>'>
            <i class="fas fa-lock"></i> &nbsp;Annuler la modification
        </a>
    </button>
    
    <!-- Bouton pour modifier le mot de passe -->
    <button type="submit">
        <a>
            <i class="fas fa-lock"></i> &nbsp; Modifier le Mot de Passe
        </a>
    </button>

</form>
<br><br>

   

   

    

</form>