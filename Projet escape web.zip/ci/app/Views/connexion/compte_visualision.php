<?php
$session=session();
echo"<h2>". $le_message."</h2>";
?>
<?php

if (isset($scenarii) && !empty($scenarii)) {
    // Vérifie si la première ligne a une question non nulle
    $fait=false;

    if ( $scenarii[0]['etp_question'] != NULL) {
        echo "<br><div class='table-responsive table-responsive-data2'>
            <table class='table table-data2'>
            <thead>
                <tr>
                    <th>Code du scénario </th>
                    <th>Intitule scenario</th>
                    <th>Description</th>
                </tr> 
            </thead><tbody>";
    }
    else{
        echo "<br><div class='table-responsive table-responsive-data2'>
        <table class='table table-data2'>
        <thead>
            <tr>
                <th>Code du scénario </th>
                <th>Intitule scénario</th>
                <th>Description</th>
                <th>Etape</th>
                </tr> 
        </thead><tbody>";
    }

    foreach ($scenarii as $pseudos) {
        if ($pseudos['etp_question'] != NULL) {
            if (!$fait){
                echo "<tr class='tr-shadow'>
                <td>" . $pseudos['sce_code'] . "</td>
                <td>" . $pseudos['sce_intitule'] . "</td>
                <td>" . $pseudos['sce_description'] . "</td>
                </tr>";
                echo "</tbody></table>";
                $fait=true;
            }
            echo"<div class='table table-data2'>";
            echo "<h4> Etape numéro ".$pseudos['etp_ordre'].":</h4>";
           echo "Intititulé de l'étape: ".$pseudos['etp_intitule']."<br>
              Question: ".  $pseudos['etp_question']."<br> 
              Réponse: " .$pseudos['etp_reponse']."<br><br></div>" ;
            
        }
        else{
            echo "<tr class='tr-shadow'>
            <td>" . $pseudos['sce_code'] . "</td>
            <td>" . $pseudos['sce_intitule'] . "</td>
            <td>" . $pseudos['sce_description'] . "</td>
            <td>Pas d'étape pour le moment</td>
        </tr>";
        echo "</tbody></table>";
        }
    }
        echo "</div>
    <br>";
}

?>
<!-- Visualisation de toutes les infos (etapes)+ressources -->
