<h2>Espace d'administration</h2>
<br>
<?php
$session=session();
echo "Affichage des données du profil ici !!!";
echo"<br><br>";
echo $session->get('user');
echo"<br><br>";
if ( isset($profil)) 
{
	echo" <br><div class='table-responsive table-responsive-data2'>
    <table class='table table-data2'>
		<tr class='tr-shadow'>
		 <th>Nom</th>
		 <td>";
        echo $profil->cpt_nom; 
        echo"</td>
		<td><div class='table-data-feature'>
			<button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		 	<i class='fas fa-edit'></i></a>
		 </button></div></td></tr>
		 <tr  class='tr-shadow'>
		 <th>Prénom</th>
		 <td>";
		 echo  $profil->cpt_prenom;
		 echo"</td>
		 <td><div class='table-data-feature'>
		 <button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		  <i class='fas fa-edit'></i></a>
	 	 </button></div></td></tr>
		 <tr  class='tr-shadow'>
		 <th>Pseudo</th>
		 <td>";
		 echo $profil->cpt_login; 
		 echo"</td>
		 <td><div class='table-data-feature'>
		 <button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		  <i class='fas fa-edit'></i></a>
	 	 </button></div></td></tr>
		 <tr  class='tr-shadow'>
		 <th>Mot de Passe</th>
		 <td>********</td>
		<td><div class='table-data-feature'>
		 <button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		  <a href='../compte/modifier'>
		  <i class='fas fa-edit'></i></a>
	  	</button></div></td>
		 <tr  class='tr-shadow'>
		 <th>Role</th>
		 <td>";
		 echo $profil->cpt_role;  
		 echo"</td>
		 <td><div class='table-data-feature'>
		 <button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		  <i class='fas fa-edit'></i></a>
	  	 </button></div></td></tr><tr  class='tr-shadow'>
		 <th>Etat</th>
		 <td>";
		 echo  $profil->cpt_etat; 
		 echo"</td><td><div class='table-data-feature'>
		 <button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>
		  <i class='fas fa-edit'></i></a>
	  	</button></div></td></tr> </table></div>";
	}
?>
<br>
<br>

