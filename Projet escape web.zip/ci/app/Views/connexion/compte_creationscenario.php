<?php
$session=session();
?>

<?= session()->getFlashdata('error') ?>
<div class="login-wrap">
<div class="login-content">
<div class="login-logo">
<h2><?php echo $titre; ?></h2>
</div>
<?php
// Création d’un formulaire qui pointe vers l’URL de base + /compte/creer
echo form_open_multipart('/scenario/creer'); ?>
 <?= csrf_field() ?>
 <div class="form-group">
 <p><label for="intitule">Intitule : </label>
 <input class="au-input au-input--full" type="input" name="intitule">
 <?= validation_show_error('intitule') ?>
 </p></div>
 <div class="form-group">
  <p><label for="description">Description: </label>
 <input class="au-input au-input--full" type="input" name="description">
  <?= validation_show_error('description') ?>
 </p></div>
 <div class="form-group">
 <p>
 <label for="fichier">Image pour le scénario : </label>
 <input type="file" name="fichier">
</p></div>
<div class="form-group"><p>
    <label for="etat">Etat :</label>
    <select class="form-select" aria-label="Default select example" name="etat" id="etat">
        <option selected="C">Choisir un état</option>
        <option value="A">Public</option>
        <option value="C">Caché</option>
    </select>
    <?= validation_show_error('etat') ?>
</p></div>

 <p><button class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="submit">Créer un nouveau scénario</button></p>
</form>
<br><br>       
</div>
</div>
