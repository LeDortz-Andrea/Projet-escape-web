<style>
.highlight {
    background-color: #add8e6; /* Remplacez par la couleur de fond que vous souhaitez */
}
</style>


<?php
$session=session();
?>

<div class="table-data-feature">
	&nbsp;Ajouter un scenario &nbsp;
	<button class="item" data-toggle="tooltip" data-placement="top" >
		<a href="<?php echo base_url();?>index.php/scenario/creer">
			<i class="fas fa-plus"></i></a>
		</button>
</div>   
<?php
if (!empty($scenarii)) {
	echo" <br><div class='table-responsive table-responsive-data2'>
    <table class='table table-data2'>
	<thead>
		<tr>
		 <th>Intitule</th>
		 <th>Image</th>
		 <th>Auteur</th>
		 <th>Nombre étape</th>
		 <th>Action</th>
		</tr> 
	</thead><tbody>";
  
     foreach ($scenarii as $pseudos) {
     	
			if ( isset($profil)) {
			 	if($profil->cpt_login== $pseudos['cpt_login']){
					echo " <tr class='tr-shadow highlight'>
					<td>";
            		echo  $pseudos['sce_intitule'];
            		echo"</td><td>";
            		echo "<i><img src='" . base_url('ressources/' . $pseudos['sce_image']) . "'width='100 px 'alt=''></i>";
            		echo"</td><td>";
           			 echo $pseudos['cpt_login'] ;
					echo"</td><td>";
					if ($pseudos['ETP']==0){
						echo"Aucune étape";

					}else{
						echo $pseudos['ETP'];
					}
					echo"</td>";
					echo"<td>";
					echo "<div class='table-data-feature '>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Visualisation'>
						<a href='". base_url('index.php/scenario/visualiser/' . $pseudos['sce_code']) ."'>
							<i class='fas fa-eye'></i>
						</a>
					</button>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Modifier'>
						<a href=''>
							<i class='fas fa-edit'></i>
						</a>
					</button>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Activation/Désactivation'>
						<a href=''>
							<i class='fas fa-toggle-on'></i>
						</a>
					</button>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Effacer'>
						<a href='#' onclick='confirmDelete(" . $pseudos['sce_id_scenario'] . ")'>
							<i class='fas fa-trash-alt'></i>
						</a>
					</button>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Remis à zéro'>
						<a href=''>
							<i class='fas fa-sync-alt'></i>
						</a>
					</button>
				</div>";
				
					
				}else{
					echo " <tr class='tr-shadow'>
    				<td>";
           			 echo  $pseudos['sce_intitule'];
            		 echo"</td><td>";
            		 echo "<i><img src='" . base_url('ressources/' . $pseudos['sce_image']) . "'width='100 px 'alt=''></i>";
           			 echo"</td><td>";
            		 echo $pseudos['cpt_login'] ;
					 echo"</td><td>";
					 if ($pseudos['ETP']==0){
						echo"Aucune étape";

					}else{
						echo $pseudos['ETP'];
					}
					 echo"</td>";
					 echo"<td>";
					echo"<div class='table-data-feature'>
					<button class='item' data-toggle='tooltip' data-placement='top' title='visualisation'>
						<a href='". base_url('index.php/scenario/visualiser/' . $pseudos['sce_code']) ."'>
						<i class='fas fa-eye'></i></a>
					</button>
					<button class='item' data-toggle='tooltip' data-placement='top' title='Copier'>
						<a href=''>
						<i class='fas fa-copy'></i></a>
					</button></div>";

				}
			}
			echo"</tr>";
	 }	
    echo"</tbody></table></div>";
}
else {
    echo("<h3>Aucun scénario pour le moment</h3>");
}

?><script>
function confirmDelete(scenarioId) {
	var confirmation = confirm("Êtes-vous sûr de vouloir supprimer ce scénario ?");
	if (confirmation) {
		window.location.href = "<?php echo base_url('index.php/scenario/supprimer/') ?>" + scenarioId;
	}
}
</script>

