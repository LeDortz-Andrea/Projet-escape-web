<?php


// echo"<h1>" .$intitule."</h1><br />";
if (isset($etapes)){
   
    echo("  <section class='full-width'>
    <div class='s-12 m-12 l-6'> ");
    echo "<i><img src='" . base_url('ressources/' . $etapes->res_chemin) . "'style='width: 700px'></i>";
    echo"</div>
    <div class='s-12 m-12 l-6'>
        <div class='padding-2x'>
          <div class='line'>
              <div class='margin-left-60 margin-bottom-30'>
              <h3 class='text-size-25 margin-bottom-0'>";
              echo  $etapes->etp_intitule."</h3>";
    if (($etapes->ind_lienIndice != null) && ($etapes->ind_lienIndice != '')) {
        echo "Cliquer sur la loupe pour voir votre Indice <a href='" . $etapes->ind_lienIndice . "'>";
        echo "<img src='" . base_url('ressources/loupes') . "' style='width: 50px;'></a>";
    } else {
       // echo "pas d'indice";
    }
    echo "<p class='text-dark'>";
    echo"<h4>". $etapes->etp_question."</h4>";
    ?>
    <?php echo form_open('/etape/franchir/'. $lecode . '/' . $niv); ?>
    <?= csrf_field() ?>
    <label for="reponse">Votre réponse : </label>
    <input type="text" name="reponse">
    <input type="hidden" name="thecode" value="<?php echo $lecode; ?>">
    <input type="hidden" name="theniv" value="<?php echo $niv; ?>">
    <input type="submit" name="submit" value="Valider">
</form>
<?php
    echo(" </div>
    </div> 
  </div>
</div>
</section>");

}
else {
    //return redirect()->to('/scenario/afficher');
    echo ("Pas d'étape !");
}

?>
<section> 
 <br> 
 <b>
</section> 