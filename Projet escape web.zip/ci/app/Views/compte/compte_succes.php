Bravo ! Formulaire rempli, le compte suivant a été ajouté :
<br>
<?php
echo"<p>";
echo $le_compte;
echo"</p><br><p>";
echo $le_message;
echo"</p><br><p>";

echo"Le nouveau nombre de comptes est ". $le_total->total;
?>
<br>
<a class="button button-dark-stroke text-size-12" href="<?php echo base_url('index.php/compte/lister'); ?>">Retour vers la page Compte</a>