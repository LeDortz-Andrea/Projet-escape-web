<?php
$session=session();
?>
<?= session()->getFlashdata('error') ?>
<div class="login-wrap">
<div class="login-content">
<div class="login-logo">
    <h2><?php echo $titre; ?></h2>
 </div>
<?php
// Création d’un formulaire qui pointe vers l’URL de base + /compte/creer
echo form_open('/compte/creer'); ?>
 <?= csrf_field() ?>
 <div class="form-group">
 <p><label for="pseudo">Pseudo : </label>
 <input class="au-input au-input--full" type="input" name="pseudo">
 <?= validation_show_error('pseudo') ?>
 </p></div>
 <div class="form-group">
  <p><label for="nom">Nom: </label>
 <input class="au-input au-input--full" type="input" name="nom">
  <?= validation_show_error('nom') ?>
 </p></div>
 <div class="form-group">
  <p><label for="prenom">Prenom : </label>
 <input class="au-input au-input--full" type="input" name="prenom">
  <?= validation_show_error('prenom') ?>
 </p></div>
 <div class="form-group">
 <p><label for="mdp2">Mot de passe : </label>
 <input class="au-input au-input--full" type="password" name="mdp">
 <?= validation_show_error('mdp') ?>
 </p></div>
 <div class="form-group">
  <p><label for="mdp"> Confirmation du Mot de passe : </label>
 <input class="au-input au-input--full" type="password" name="mdp2">
 <?= validation_show_error('mdp2') ?>
 </p></div>
 <div class="form-group">
 <p>
    <label for="role">Rôle :</label>
    <select class="form-select" aria-label="Default select example" name="role" id="role">
        <option selected="O">Choisir un rôle</option>
        <option value="O">Organisateur</option>
        <option value="A">Administrateur</option>
    </select>
    <?= validation_show_error('role') ?>
</p>
</div>
<button class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="submit">Créer un nouveau compte</button>

</form>
<br><br>
        
</div>
</div>

             