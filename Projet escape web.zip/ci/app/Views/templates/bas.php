<footer>
      <!-- Main Footer -->
      <section class="background-dark full-width">
      <!-- Bottom Footer -->
      <section class="padding background-dark full-width">
        <div class="s-12 l-6">
          <p class="text-size-12">Copyright 2023</p>
          <p class="text-size-12">Morbihan</p>
        </div>
        <div class="s-12 l-6">
          <a class="right text-size-12" href="http://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and coding<br> by LE DORTZ Andréa</a>
        </div>
      </section>
    </footer>  
	<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/responsee.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>bootstrap/owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/template-scripts.js"></script>  
</body>
</html>

