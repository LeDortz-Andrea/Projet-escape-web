<!DOCTYPE html>

<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>escapeweb </title>
	<link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/components.css">
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/icons.css">
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/responsee.css">
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/owl-carousel/owl.theme.css">     
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/template-style.css">
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/jquery-ui.min.js"></script>    
  </head>

  <body class="size-1140">
    <!-- HEADER 
    <header role="banner" class="position-absolute">    
      Top Navigation 
      <nav class="background-transparent background-transparent-hightlight full-width sticky">
        <div class="s-12 l-2">
          <a href="index.html" class="logo">
            Logo White Version 
            <img class="logo-white" src="<?php echo base_url();?>bootstrap/img/Morbihandark.png" alt="">
             Logo Dark Version 
            <img class="logo-dark" src="<?php echo base_url();?>bootstrap/img/morbihan3.png" alt="">
          </a>
        </div>
        <div class="top-nav s-12 l-10">
          <p class="nav-text"></p>
          <ul class="right chevron">
            <li><a href="index.html">Home</a></li>
            <li><a href="products.html">Products</a></li>
            <li><a>Services</a>
              <ul>
                <li><a>Service 1</a>
                  <ul>
                    <li><a>Service 1 A</a></li>
                    <li><a>Service 1 B</a></li>
                  </ul>
                </li>
                <li><a>Service 2</a></li>
              </ul>
            </li>
            <li><a href="about.html">About</a></li>
            <li><a href="gallery.html">Gallery</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
      </nav>
    </header>-->
    
    <!-- MAIN -->
    <main role="main">    
      <!-- Main Header -->
      <header>
        <div class="carousel-default owl-carousel carousel-main carousel-nav-white background-dark text-center">
          <div class="item">
            <div class="s-12">
              <img src="<?php echo base_url();?>bootstrap/img/accueil.jpg" alt="">
              <div class="carousel-content">
                <div class="content-center-vertical line">
                  <div class="margin-top-bottom-80">
                    <!-- Title -->
                    <h1 class="text-white margin-bottom-30 text-size-60 text-m-size-30 text-line-height-1">Découvrer le Morbihan<br> </h1>
                    <div class="s-12 m-10 l-8 center"><p class="text-white text-size-14 margin-bottom-40">Tester vos connaissances sur les villes du morbihan </p></div>
                    <div class="line">
                      <div class="s-12 m-12 l-3 center">
                        
                      </div>       
                    </div>  
                  </div>
                </div>
              </div>
            </div>
          </div>              
        </div>               
      </header>
    
      
