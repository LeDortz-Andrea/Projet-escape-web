<header class="header-desktop3 d-none d-lg-block">
            <div class="section__content section__content--p35">
                <div class="header3-wrap">
                    <div class="header__logo">
                        <a href="#">
                            <img src="<?php echo base_url();?>bootstrap2/images/icon/Morbihandark.png" alt="CoolAdmin" />
                        </a>
                    </div>
                  
                    <div class="header__tool">
                        <div class="header__navbar">
                            <ul class="list-unstyled">
                            <li class="has-sub">
                                    <a href="<?php echo base_url();?>index.php/compte/connecter">
                                        <i class="fas fa-copy"></i>
                                        <span class="bot-line"></span>Accueil
                                    </a>    
                                </li>
                                <li class="has-sub">
                                    <a href="<?php echo base_url();?>index.php/compte/afficher_profil">
                                        <i class="fas fa-copy"></i>
                                        <span class="bot-line"></span>Mon Profil
                                    </a>    
                                </li>
                                <li class="has-sub">
                                    <a href="<?php echo base_url();?>index.php/scenario/gestion">
                                    <i class="fas fa-eye"></i> 
                                        <span class="bot-line"></span>Scenarii
                                    </a>   
                                </li>
                                <li class="has-sub">
                                    <a href="<?php echo base_url();?>index.php/compte/deconnecter">
                                        <i class="fas fa-desktop"></i>
                                        <span class="bot-line"></span>Deconnexion
                                    </a>   
                                </li>
                                <li class="has-sub">
                                <div class="header-button-item has-noti js-item-menu">
                                    <i class="zmdi zmdi-notifications"></i>
                                </div>
                                </li>
                                <li class="has-sub">
                                <div class="header-button-item js-item-menu">
                                    <i class="zmdi zmdi-settings"></i>
                                </div>
                                </li>
                                <li class="has-sub">
                                <div class="account-wrap">
                                    <div class="account-item account-item--style2 clearfix js-item-menu">
                                         <div class="image">
                                            <img src="<?php echo base_url();?>bootstrap2/images/icon/avatar.jpg" alt="John Doe" />
                                        </div>
                                    </div>
                                </div>
                                </li>
                            </ul>
                        </div>    
                    </div>       
                </div>  
             </div>
         </div>
    </div>
</header>