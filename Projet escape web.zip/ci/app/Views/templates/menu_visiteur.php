 <header role="banner" class="position-absolute">    
      <!-- Top Navigation -->
      <nav class="background-transparent background-transparent-hightlight full-width sticky">
        <div class="s-12 l-2">
          <a href="index.html" class="logo">
            <!-- Logo White Version -->
            <img class="logo-white" src="<?php echo base_url();?>bootstrap/img/Morbihandark.png" alt="">
            <!-- Logo Dark Version -->
            <img class="logo-dark" src="<?php echo base_url();?>bootstrap/img/morbihan3.png" alt="">
          </a>
        </div>
        <div class="top-nav s-12 l-10">
          <p class="nav-text"></p>
          <ul class="right chevron">
            <li><a href="<?php echo base_url();?>">Accueil</a></li>
            
            <!--<li><a>Services</a>
              <ul>
                <li><a>Service 1</a>
                  <ul>
                    <li><a>Service 1 A</a></li>
                    <li><a>Service 1 B</a></li>
                  </ul>
                </li>
                <li><a>Service 2</a></li>
              </ul>-->
            </li>
            <!--<li><a href="about.html">About</a></li>-->
            <li><a href="<?php echo base_url();?>index.php/scenario/afficher">Scenario</a></li>
            <li><a href=" <?php echo base_url();?>index.php/compte/connecter">Connexion</a></li>
           <!-- <li><a href="contact.html">Contact</a></li>-->
          </ul>
        </div>
      </nav>
    </header>